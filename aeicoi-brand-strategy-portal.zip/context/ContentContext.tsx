import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { AppContent } from '../types';
import { defaultContent } from '../data/defaultContent';

interface ContentContextType {
  content: AppContent;
  isAdmin: boolean;
  toggleAdmin: () => void;
  updateContent: (path: string, value: any) => void;
  resetContent: () => void;
  saveContent: () => void;
  hasUnsavedChanges: boolean;
}

const ContentContext = createContext<ContentContextType | undefined>(undefined);

export const ContentProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [content, setContent] = useState<AppContent>(defaultContent);
  const [isAdmin, setIsAdmin] = useState(false);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  // Load from local storage on mount
  useEffect(() => {
    const saved = localStorage.getItem('aeicoi_content');
    if (saved) {
      try {
        setContent(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to parse saved content", e);
      }
    }
  }, []);

  const toggleAdmin = () => setIsAdmin(prev => !prev);

  // Deep update helper
  const updateContent = (path: string, value: any) => {
    setHasUnsavedChanges(true);
    setContent(prev => {
      const newData = JSON.parse(JSON.stringify(prev)); // Deep clone
      const keys = path.split('.');
      let current = newData;
      
      for (let i = 0; i < keys.length - 1; i++) {
        if (keys[i].includes('[')) {
            // Handle array indexing like values[0]
            const [key, indexStr] = keys[i].split('[');
            const index = parseInt(indexStr.replace(']', ''));
            current = current[key][index];
        } else {
            current = current[keys[i]];
        }
      }
      
      const lastKey = keys[keys.length - 1];
       if (lastKey.includes('[')) {
            const [key, indexStr] = lastKey.split('[');
            const index = parseInt(indexStr.replace(']', ''));
            current[key][index] = value;
        } else {
            current[lastKey] = value;
        }
        
      return newData;
    });
  };

  const saveContent = () => {
    localStorage.setItem('aeicoi_content', JSON.stringify(content));
    setHasUnsavedChanges(false);
    alert("Content saved successfully!");
  };

  const resetContent = () => {
    if (window.confirm("Are you sure? This will discard all your changes.")) {
      setContent(defaultContent);
      localStorage.removeItem('aeicoi_content');
      setHasUnsavedChanges(false);
    }
  };

  return (
    <ContentContext.Provider value={{ 
      content, 
      isAdmin, 
      toggleAdmin, 
      updateContent, 
      resetContent, 
      saveContent,
      hasUnsavedChanges 
    }}>
      {children}
    </ContentContext.Provider>
  );
};

export const useContent = () => {
  const context = useContext(ContentContext);
  if (context === undefined) {
    throw new Error('useContent must be used within a ContentProvider');
  }
  return context;
};
