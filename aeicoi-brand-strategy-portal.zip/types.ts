export interface NavItem {
  id: string;
  label: string;
}

export interface PlatformStrategyItem {
  platform: string;
  role: string;
  slogan: string;
  icon: 'youtube' | 'instagram' | 'tiktok' | 'facebook';
  tactics: string[];
  color: string;
}

export interface CoreValue {
  title: string;
  subtitle: string;
  description: string;
}

export interface DeepDiveItem {
  title: string;
  summary: string;
  fullContent: string;
}

export interface HeroContent {
  tagline: string;
  titlePart1: string;
  titleHighlight: string;
  titlePart2: string;
  subTitleEnglish: string;
  description: string;
  primaryBtnText: string;
  primaryBtnLink: string;
  secondaryBtnText: string;
  secondaryBtnLink: string;
  productImage: string; // Base64 or URL
  floatingTag1Title: string;
  floatingTag1Sub: string;
  floatingTag2Title: string;
  floatingTag2Sub: string;
}

export interface BrandCoreContent {
  sectionTitle: string;
  sectionDesc: string;
  values: CoreValue[];
}

export interface PlatformContent {
  sectionTitle: string;
  sectionDesc: string;
  strategies: PlatformStrategyItem[];
}

export interface DeepDiveContent {
  sectionTitle: string;
  sectionDesc: string;
  items: DeepDiveItem[];
}

export interface SmileBoxContent {
  sectionTitle: string;
  sectionHighlight: string;
  sectionSub: string;
  quote: string;
  designTitle: string;
  designDesc: string;
  visualTitle: string;
  visualDesc: string;
  audioTitle: string;
  audioDesc: string;
  boxImageTextTop: string;
  boxImageTextBottom: string;
}

export interface RedLinesContent {
  sectionTitle: string;
  sectionDesc: string;
  visualTitle: string;
  colorTitle: string;
  colorDesc: string;
  fontTitle: string;
  fontDesc: string;
  audioTitle: string;
  personaTitle: string;
  personaDesc: string[];
  dontsTitle: string;
  dontsList: string[];
}

export interface AppContent {
  hero: HeroContent;
  brandCore: BrandCoreContent;
  platform: PlatformContent;
  deepDive: DeepDiveContent;
  smileBox: SmileBoxContent;
  redLines: RedLinesContent;
}