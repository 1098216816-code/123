import React from 'react';
import { Youtube, Instagram, Facebook, Video } from 'lucide-react';
import { useContent } from '../context/ContentContext';
import { EditableText } from './cms/AdminComponents';

export const PlatformStrategy: React.FC = () => {
  const { content } = useContent();
  const platform = content.platform;

  return (
    <section id="platforms" className="py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-display font-bold text-slate-900 mb-4">
            <EditableText path="platform.sectionTitle" value={platform.sectionTitle} />
          </h2>
          <p className="text-slate-500 max-w-2xl mx-auto">
            <EditableText path="platform.sectionDesc" value={platform.sectionDesc} />
          </p>
        </div>

        <div className="grid md:grid-cols-2 xl:grid-cols-4 gap-6">
          {platform.strategies.map((strategy, idx) => (
            <div 
              key={idx}
              className={`bg-white rounded-2xl p-6 border border-slate-100 transition-all duration-300 group ${strategy.color} hover:-translate-y-2`}
            >
              <div className="flex items-center justify-between mb-6">
                <div className={`p-3 rounded-xl bg-slate-50 group-hover:bg-white group-hover:shadow-md transition-colors`}>
                  {strategy.icon === 'youtube' && <Youtube className="text-red-600" size={24} />}
                  {strategy.icon === 'instagram' && <Instagram className="text-pink-600" size={24} />}
                  {strategy.icon === 'tiktok' && <Video className="text-slate-900" size={24} />}
                  {strategy.icon === 'facebook' && <Facebook className="text-blue-600" size={24} />}
                </div>
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                    <EditableText path={`platform.strategies[${idx}].role`} value={strategy.role} />
                </span>
              </div>

              <h3 className="text-xl font-bold text-slate-900 mb-1">
                 <EditableText path={`platform.strategies[${idx}].platform`} value={strategy.platform} />
              </h3>
              <div className="text-sm font-medium text-brand-600 mb-6 italic">
                 <EditableText path={`platform.strategies[${idx}].slogan`} value={strategy.slogan} />
              </div>

              <ul className="space-y-3">
                {strategy.tactics.map((tactic, tIdx) => (
                  <li key={tIdx} className="flex items-start gap-2 text-sm text-slate-600">
                    <span className="w-1.5 h-1.5 rounded-full bg-brand-300 mt-1.5 flex-shrink-0" />
                    <span className="w-full">
                         <EditableText path={`platform.strategies[${idx}].tactics[${tIdx}]`} value={tactic} multiline />
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
