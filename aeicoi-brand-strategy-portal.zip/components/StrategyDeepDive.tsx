import React, { useState } from 'react';
import { ArrowRight, X, BookOpen } from 'lucide-react';
import { useContent } from '../context/ContentContext';
import { EditableText } from './cms/AdminComponents';

export const StrategyDeepDive: React.FC = () => {
  const { content } = useContent();
  const { deepDive } = content;
  const [openModalIndex, setOpenModalIndex] = useState<number | null>(null);

  return (
    <section id="deep-dive" className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-display font-bold text-slate-900 mb-4">
            <EditableText path="deepDive.sectionTitle" value={deepDive.sectionTitle} />
          </h2>
          <p className="text-slate-500 max-w-2xl mx-auto">
            <EditableText path="deepDive.sectionDesc" value={deepDive.sectionDesc} />
          </p>
        </div>

        <div className="flex flex-col gap-6">
          {deepDive.items.map((item, index) => (
            <div 
              key={index} 
              className="group flex flex-col md:flex-row items-stretch md:items-center bg-slate-50 border border-slate-100 rounded-2xl p-2 hover:shadow-lg transition-all duration-300"
            >
              {/* The "Theme Button" */}
              <button
                onClick={() => setOpenModalIndex(index)}
                className="flex-shrink-0 bg-white border border-brand-200 text-brand-700 font-display font-bold text-lg px-8 py-6 rounded-xl shadow-sm group-hover:bg-brand-500 group-hover:text-white group-hover:border-brand-500 transition-colors duration-300 text-left md:text-center w-full md:w-64 flex items-center justify-between md:justify-center"
              >
                <span className="truncate">
                    <EditableText path={`deepDive.items[${index}].title`} value={item.title} />
                </span>
                <ArrowRight className="w-5 h-5 md:hidden opacity-50" />
              </button>

              {/* The "Brief Intro" */}
              <div className="flex-1 px-6 py-4 flex flex-col justify-center">
                 <p className="text-slate-600 group-hover:text-slate-900 transition-colors">
                    <EditableText path={`deepDive.items[${index}].summary`} value={item.summary} />
                 </p>
              </div>

              {/* Action */}
              <button 
                 onClick={() => setOpenModalIndex(index)}
                 className="hidden md:flex items-center justify-center w-16 h-16 rounded-xl bg-white text-slate-300 group-hover:text-brand-500 group-hover:translate-x-1 transition-all duration-300"
              >
                 <ArrowRight size={24} />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Modal Overlay */}
      {openModalIndex !== null && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
           {/* Backdrop */}
           <div 
             className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200"
             onClick={() => setOpenModalIndex(null)}
           />
           
           {/* Modal Content */}
           <div className="relative bg-white w-full max-w-3xl max-h-[85vh] rounded-3xl shadow-2xl overflow-hidden flex flex-col animate-in zoom-in-95 duration-200">
              
              {/* Header */}
              <div className="p-8 border-b border-slate-100 flex items-start justify-between bg-brand-50/50">
                 <div>
                    <div className="flex items-center gap-2 text-brand-600 mb-2">
                        <BookOpen size={20} />
                        <span className="text-sm font-bold uppercase tracking-wider">Strategy Detail</span>
                    </div>
                    <h3 className="text-3xl font-display font-bold text-slate-900">
                        <EditableText path={`deepDive.items[${openModalIndex}].title`} value={deepDive.items[openModalIndex].title} />
                    </h3>
                 </div>
                 <button 
                   onClick={() => setOpenModalIndex(null)}
                   className="p-2 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-600 transition-colors"
                 >
                   <X size={24} />
                 </button>
              </div>

              {/* Scrollable Body */}
              <div className="p-8 overflow-y-auto custom-scrollbar">
                 <div className="prose prose-slate prose-lg max-w-none text-slate-600 whitespace-pre-wrap">
                    <EditableText 
                        path={`deepDive.items[${openModalIndex}].fullContent`} 
                        value={deepDive.items[openModalIndex].fullContent} 
                        multiline 
                        as="div"
                    />
                 </div>
              </div>

              {/* Footer */}
              <div className="p-4 bg-slate-50 border-t border-slate-100 flex justify-end">
                  <button 
                    onClick={() => setOpenModalIndex(null)}
                    className="px-6 py-2 bg-slate-900 text-white rounded-lg hover:bg-slate-800 transition-colors font-medium text-sm"
                  >
                    Close
                  </button>
              </div>

           </div>
        </div>
      )}
    </section>
  );
};