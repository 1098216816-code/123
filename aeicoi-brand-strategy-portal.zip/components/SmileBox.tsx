import React from 'react';
import { PackageOpen, Camera, Music, Sparkles } from 'lucide-react';
import { useContent } from '../context/ContentContext';
import { EditableText } from './cms/AdminComponents';

export const SmileBox: React.FC = () => {
  const { content } = useContent();
  const smile = content.smileBox;

  return (
    <section id="smile-box" className="py-24 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex flex-col md:flex-row gap-16 items-center">
          
          <div className="flex-1 order-2 md:order-1">
            <h2 className="text-3xl md:text-5xl font-display font-bold text-slate-900 mb-6">
              <EditableText path="smileBox.sectionTitle" value={smile.sectionTitle} /> <br/>
              <span className="text-brand-600"><EditableText path="smileBox.sectionHighlight" value={smile.sectionHighlight} /></span> <EditableText path="smileBox.sectionSub" value={smile.sectionSub} />
            </h2>
            <p className="text-xl text-slate-600 mb-8 font-light italic">
              <EditableText path="smileBox.quote" value={smile.quote} />
            </p>

            <div className="space-y-8">
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-brand-50 flex items-center justify-center text-brand-600">
                  <PackageOpen size={24} />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 mb-1">
                      <EditableText path="smileBox.designTitle" value={smile.designTitle} />
                  </h4>
                  <div className="text-slate-600 text-sm">
                    <EditableText path="smileBox.designDesc" value={smile.designDesc} multiline />
                  </div>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-brand-50 flex items-center justify-center text-brand-600">
                  <Camera size={24} />
                </div>
                <div>
                   <h4 className="font-bold text-slate-900 mb-1">
                      <EditableText path="smileBox.visualTitle" value={smile.visualTitle} />
                  </h4>
                  <div className="text-slate-600 text-sm">
                    <EditableText path="smileBox.visualDesc" value={smile.visualDesc} multiline />
                  </div>
                </div>
              </div>
              
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-brand-50 flex items-center justify-center text-brand-600">
                  <Music size={24} />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 mb-1">
                      <EditableText path="smileBox.audioTitle" value={smile.audioTitle} />
                  </h4>
                  <div className="text-slate-600 text-sm">
                    <EditableText path="smileBox.audioDesc" value={smile.audioDesc} multiline />
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="flex-1 order-1 md:order-2 relative group cursor-pointer">
             {/* Abstract Visual Representation of the Box */}
             <div className="relative w-full aspect-[4/5] bg-gradient-to-b from-white to-brand-50 rounded-[3rem] shadow-2xl border border-slate-100 overflow-hidden transform transition-transform duration-700 group-hover:scale-105">
                {/* The Smile Curve */}
                <div className="absolute top-1/2 left-0 w-full h-32 -translate-y-1/2">
                   <svg viewBox="0 0 100 20" className="w-full h-full drop-shadow-xl">
                      <path d="M0,0 Q50,20 100,0" fill="none" stroke="#fbbf24" strokeWidth="3" />
                   </svg>
                </div>
                
                {/* Top Half (White) */}
                <div className="absolute top-0 left-0 w-full h-1/2 bg-white flex items-center justify-center">
                   <span className="text-brand-900 font-display font-bold text-4xl opacity-90">
                       <EditableText path="smileBox.boxImageTextTop" value={smile.boxImageTextTop} />
                   </span>
                </div>

                {/* Bottom Half (Blue) */}
                <div className="absolute bottom-0 left-0 w-full h-1/2 bg-brand-600 flex items-end justify-center pb-12">
                   <div className="text-white/80 font-sans text-sm tracking-widest uppercase">
                       <EditableText path="smileBox.boxImageTextBottom" value={smile.boxImageTextBottom} />
                   </div>
                </div>

                {/* Interactive Overlay */}
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/5 transition-colors duration-300 flex items-center justify-center">
                    <div className="bg-white/90 backdrop-blur text-brand-800 px-6 py-3 rounded-full opacity-0 group-hover:opacity-100 translate-y-4 group-hover:translate-y-0 transition-all duration-500 shadow-xl flex items-center gap-2">
                        <Sparkles className="text-yellow-500 w-4 h-4" />
                        <span>Open the box</span>
                    </div>
                </div>
             </div>
          </div>

        </div>
      </div>
    </section>
  );
};
