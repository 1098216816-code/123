import React, { useRef } from 'react';
import { useContent } from '../../context/ContentContext';
import { Edit2, Save, RotateCcw, ImagePlus, Link } from 'lucide-react';

// --- Floating Admin Toolbar ---
export const AdminToolbar: React.FC = () => {
  const { isAdmin, toggleAdmin, saveContent, resetContent, hasUnsavedChanges } = useContent();

  return (
    <div className="fixed bottom-6 right-6 z-[100] flex flex-col gap-3 items-end">
      {isAdmin && (
        <div className="bg-white p-2 rounded-xl shadow-2xl border border-slate-200 flex flex-col gap-2 animate-in fade-in slide-in-from-bottom-4">
           <button 
            onClick={saveContent}
            className={`p-3 rounded-lg flex items-center gap-2 font-medium transition-all ${hasUnsavedChanges ? 'bg-green-500 text-white shadow-green-200 shadow-lg' : 'bg-slate-100 text-slate-400'}`}
            title="Save Changes"
          >
            <Save size={20} />
            <span className="text-xs">保存</span>
          </button>
          <button 
            onClick={resetContent}
            className="p-3 bg-red-50 hover:bg-red-100 text-red-600 rounded-lg transition-colors"
            title="Reset to Default"
          >
            <RotateCcw size={20} />
          </button>
        </div>
      )}
      
      <button 
        onClick={toggleAdmin}
        className={`p-4 rounded-full shadow-xl transition-all duration-300 ${
          isAdmin ? 'bg-brand-600 text-white rotate-0' : 'bg-slate-800 text-white hover:bg-brand-600'
        }`}
      >
        <Edit2 size={24} />
      </button>
    </div>
  );
};

// --- Editable Text Component ---
interface EditableTextProps {
  path: string;
  value: string;
  as?: 'h1' | 'h2' | 'h3' | 'h4' | 'p' | 'span' | 'div';
  className?: string;
  multiline?: boolean;
}

export const EditableText: React.FC<EditableTextProps> = ({ path, value, as: Tag = 'span', className, multiline }) => {
  const { isAdmin, updateContent } = useContent();

  if (!isAdmin) {
    return <Tag className={className} style={multiline ? { whiteSpace: 'pre-wrap' } : undefined}>{value}</Tag>;
  }

  return (
    <div className="relative group min-w-[20px]">
       {multiline ? (
        <textarea
          value={value}
          onChange={(e) => updateContent(path, e.target.value)}
          className={`w-full bg-brand-50/50 hover:bg-white border border-transparent hover:border-brand-300 focus:border-brand-500 focus:ring-2 focus:ring-brand-200 rounded p-1 outline-none transition-all resize-y ${className}`}
          rows={5}
        />
       ) : (
        <input
          type="text"
          value={value}
          onChange={(e) => updateContent(path, e.target.value)}
          className={`w-full bg-brand-50/50 hover:bg-white border border-transparent hover:border-brand-300 focus:border-brand-500 focus:ring-2 focus:ring-brand-200 rounded px-1 outline-none transition-all ${className}`}
        />
       )}
       <span className="absolute -top-2 -right-2 opacity-0 group-hover:opacity-100 bg-brand-600 text-white text-[10px] px-1 rounded pointer-events-none z-10">Edit</span>
    </div>
  );
};

// --- Editable Image Component ---
interface EditableImageProps {
  path: string;
  src: string;
  alt: string;
  className?: string;
  fallback?: React.ReactNode;
}

export const EditableImage: React.FC<EditableImageProps> = ({ path, src, alt, className, fallback }) => {
  const { isAdmin, updateContent } = useContent();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        updateContent(path, reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const content = src ? (
    <img src={src} alt={alt} className={className} />
  ) : (
    fallback || <div className={`bg-slate-200 flex items-center justify-center ${className}`}><span className="text-slate-400">No Image</span></div>
  );

  if (!isAdmin) return <>{content}</>;

  return (
    <div className={`relative group cursor-pointer ${className}`} onClick={() => fileInputRef.current?.click()}>
      {content}
      <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity rounded-[inherit] z-10">
        <div className="text-white flex flex-col items-center gap-2">
          <ImagePlus size={24} />
          <span className="text-xs font-bold">Replace Image</span>
        </div>
      </div>
      <input 
        type="file" 
        ref={fileInputRef} 
        onChange={handleFileChange} 
        accept="image/*" 
        className="hidden" 
      />
    </div>
  );
};

// --- Editable Link/Button Component ---
interface EditableLinkProps {
  pathText: string;
  pathLink: string;
  text: string;
  link: string;
  className?: string;
  icon?: React.ReactNode;
  onLinkClick?: (id: string) => void;
}

export const EditableLink: React.FC<EditableLinkProps> = ({ pathText, pathLink, text, link, className, icon, onLinkClick }) => {
  const { isAdmin, updateContent } = useContent();
  
  if (!isAdmin) {
    return (
      <button onClick={() => onLinkClick?.(link)} className={className}>
        {text}
        {icon}
      </button>
    );
  }

  return (
    <div className={`relative p-2 border border-dashed border-brand-300 rounded-lg flex flex-col gap-2 bg-white/50 ${className?.replace('px-8 py-4', 'p-2')}`}>
      <div className="flex items-center gap-2 w-full">
        <Edit2 size={12} className="text-slate-400" />
        <input 
           value={text} 
           onChange={(e) => updateContent(pathText, e.target.value)}
           className="bg-transparent text-sm font-bold w-full outline-none"
           placeholder="Button Text"
        />
      </div>
      <div className="flex items-center gap-2 w-full border-t border-slate-100 pt-1">
        <Link size={12} className="text-slate-400" />
        <input 
           value={link} 
           onChange={(e) => updateContent(pathLink, e.target.value)}
           className="bg-transparent text-xs text-slate-500 w-full outline-none font-mono"
           placeholder="Target ID (e.g. smile-box)"
        />
      </div>
    </div>
  );
};