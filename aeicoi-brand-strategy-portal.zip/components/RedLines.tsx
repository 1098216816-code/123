import React from 'react';
import { Check, X, Palette, Type, Mic, AlertOctagon } from 'lucide-react';
import { useContent } from '../context/ContentContext';
import { EditableText } from './cms/AdminComponents';

export const RedLines: React.FC = () => {
  const { content } = useContent();
  const lines = content.redLines;

  return (
    <section id="guidelines" className="py-20 bg-slate-900 text-white relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-brand-600/20 rounded-full blur-[100px]"></div>
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-purple-600/20 rounded-full blur-[100px]"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
        <div className="mb-16 border-b border-slate-700 pb-8">
          <h2 className="text-3xl md:text-4xl font-display font-bold mb-4">
             <EditableText path="redLines.sectionTitle" value={lines.sectionTitle} />
          </h2>
          <p className="text-slate-400">
             <EditableText path="redLines.sectionDesc" value={lines.sectionDesc} />
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12">
          
          {/* Visual Side */}
          <div className="space-y-8">
            <h3 className="text-2xl font-bold flex items-center gap-3 text-brand-400">
              <Palette className="w-6 h-6" />
              <EditableText path="redLines.visualTitle" value={lines.visualTitle} />
            </h3>
            
            <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
              <h4 className="font-bold mb-4 text-white">
                  <EditableText path="redLines.colorTitle" value={lines.colorTitle} />
              </h4>
              <div className="flex gap-4 mb-4">
                <div className="w-12 h-12 rounded-full bg-brand-600 border-2 border-white shadow-lg"></div>
                <div className="w-12 h-12 rounded-full bg-white border-2 border-slate-200"></div>
                <div className="w-12 h-12 rounded-full bg-yellow-400 border-2 border-white"></div>
              </div>
              <div className="space-y-2 text-sm text-slate-300">
                  <div className="flex items-start gap-2">
                     <Check className="w-4 h-4 text-green-400 mt-1 flex-shrink-0" />
                     <EditableText path="redLines.colorDesc" value={lines.colorDesc} multiline />
                  </div>
              </div>
            </div>

             <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
              <h4 className="font-bold mb-4 text-white flex items-center gap-2">
                  <Type className="w-4 h-4" /> 
                  <EditableText path="redLines.fontTitle" value={lines.fontTitle} />
              </h4>
              <div className="text-sm text-slate-300">
                 <EditableText path="redLines.fontDesc" value={lines.fontDesc} multiline />
              </div>
            </div>
          </div>

          {/* Audio & Behavior Side */}
          <div className="space-y-8">
            <h3 className="text-2xl font-bold flex items-center gap-3 text-yellow-400">
              <Mic className="w-6 h-6" />
               <EditableText path="redLines.audioTitle" value={lines.audioTitle} />
            </h3>

             <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
              <h4 className="font-bold mb-4 text-white">
                 <EditableText path="redLines.personaTitle" value={lines.personaTitle} />
              </h4>
              <ul className="space-y-3 text-sm text-slate-300">
                {lines.personaDesc.map((item, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-slate-500 mt-2 flex-shrink-0"></span>
                      <EditableText path={`redLines.personaDesc[${idx}]`} value={item} />
                    </li>
                ))}
              </ul>
            </div>

            <div className="bg-red-900/20 rounded-2xl p-6 border border-red-900/50">
              <h4 className="font-bold mb-4 text-red-400 flex items-center gap-2">
                  <AlertOctagon className="w-4 h-4" /> 
                  <EditableText path="redLines.dontsTitle" value={lines.dontsTitle} />
              </h4>
               <ul className="grid grid-cols-2 gap-4 text-sm text-slate-300">
                 {lines.dontsList.map((item, idx) => (
                    <li key={idx} className="flex items-center gap-2">
                        <X className="w-4 h-4 text-red-500 flex-shrink-0" /> 
                        <EditableText path={`redLines.dontsList[${idx}]`} value={item} />
                    </li>
                 ))}
               </ul>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
