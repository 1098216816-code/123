import React from 'react';
import { ArrowRight, Box, Heart } from 'lucide-react';
import { useContent } from '../context/ContentContext';
import { EditableText, EditableImage, EditableLink } from './cms/AdminComponents';

interface HeroProps {
  scrollToSection: (id: string) => void;
}

export const Hero: React.FC<HeroProps> = ({ scrollToSection }) => {
  const { content } = useContent();
  const h = content.hero;

  return (
    <section id="hero" className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden">
      {/* Background Elements */}
      <div className="absolute top-0 right-0 -translate-y-1/4 translate-x-1/4 w-[600px] h-[600px] bg-brand-400/20 rounded-full blur-3xl" />
      <div className="absolute bottom-0 left-0 translate-y-1/4 -translate-x-1/4 w-[500px] h-[500px] bg-blue-300/20 rounded-full blur-3xl" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
        <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-20">
          
          <div className="flex-1 text-center lg:text-left w-full">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-50 border border-brand-100 text-brand-600 text-sm font-semibold mb-6">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-brand-500"></span>
              </span>
              <EditableText path="hero.tagline" value={h.tagline} />
            </div>
            
            <h1 className="text-4xl lg:text-6xl font-display font-extrabold text-slate-900 tracking-tight leading-[1.1] mb-6">
              <EditableText path="hero.titlePart1" value={h.titlePart1} />{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-600 to-brand-400 inline-block">
                 <EditableText path="hero.titleHighlight" value={h.titleHighlight} />
              </span>{' '}
              <EditableText path="hero.titlePart2" value={h.titlePart2} />
              <br />
              <span className="text-3xl lg:text-5xl font-light text-slate-400 mt-2 block">
                <EditableText path="hero.subTitleEnglish" value={h.subTitleEnglish} />
              </span>
            </h1>
            
            <div className="text-lg text-slate-600 mb-8 max-w-xl mx-auto lg:mx-0 leading-relaxed">
              <EditableText path="hero.description" value={h.description} multiline />
            </div>

            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-4">
              <EditableLink 
                pathText="hero.primaryBtnText"
                pathLink="hero.primaryBtnLink"
                text={h.primaryBtnText}
                link={h.primaryBtnLink}
                onLinkClick={scrollToSection}
                className="group px-8 py-4 bg-brand-600 hover:bg-brand-700 text-white rounded-2xl font-semibold shadow-lg shadow-brand-500/30 transition-all hover:-translate-y-1 flex items-center gap-2 cursor-pointer"
                icon={<ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />}
              />
              
              <EditableLink 
                pathText="hero.secondaryBtnText"
                pathLink="hero.secondaryBtnLink"
                text={h.secondaryBtnText}
                link={h.secondaryBtnLink}
                onLinkClick={scrollToSection}
                className="px-8 py-4 bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 rounded-2xl font-semibold transition-all hover:border-brand-300 flex items-center gap-2 cursor-pointer"
                icon={<Box className="w-4 h-4" />}
              />
            </div>
          </div>

          <div className="flex-1 relative w-full">
            <div className="relative w-full max-w-lg mx-auto aspect-square">
                {/* Simulated Product Box / Visual */}
                <div className="w-full h-full relative z-10">
                   <EditableImage 
                      path="hero.productImage"
                      src={h.productImage}
                      alt="Hero Product"
                      className="w-full h-full object-contain rounded-[3rem] shadow-2xl"
                      fallback={
                        <div className="w-full h-full bg-gradient-to-br from-brand-500 to-brand-600 rounded-[3rem] shadow-2xl rotate-3 flex items-center justify-center overflow-hidden relative">
                            <div className="absolute top-0 left-0 w-full h-full opacity-10 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]"></div>
                            <div className="text-center text-white p-8">
                                <Heart className="w-20 h-20 mx-auto mb-4 text-white fill-white/20 animate-pulse" />
                                <h3 className="text-3xl font-bold font-display">The Smile Box</h3>
                                <p className="opacity-90 mt-2">Pure • Joy • Vitality</p>
                            </div>
                        </div>
                      }
                   />
                </div>
                
                {/* Floating Elements */}
                <div className="absolute -top-4 -right-4 bg-white p-4 rounded-2xl shadow-xl animate-float z-20">
                    <div className="text-sm font-bold text-brand-600">
                        <EditableText path="hero.floatingTag1Title" value={h.floatingTag1Title} />
                    </div>
                    <div className="text-xs text-slate-500">
                        <EditableText path="hero.floatingTag1Sub" value={h.floatingTag1Sub} />
                    </div>
                </div>
                <div className="absolute -bottom-6 left-8 bg-white p-4 rounded-2xl shadow-xl animate-float z-20" style={{ animationDelay: '2.5s' }}>
                    <div className="text-sm font-bold text-brand-600">
                         <EditableText path="hero.floatingTag2Title" value={h.floatingTag2Title} />
                    </div>
                    <div className="text-xs text-slate-500">
                        <EditableText path="hero.floatingTag2Sub" value={h.floatingTag2Sub} />
                    </div>
                </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};