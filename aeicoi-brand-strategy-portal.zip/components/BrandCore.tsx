import React, { useState } from 'react';
import { Heart, Activity, CheckCircle2 } from 'lucide-react';
import { useContent } from '../context/ContentContext';
import { EditableText } from './cms/AdminComponents';

export const BrandCore: React.FC = () => {
  const [activeTab, setActiveTab] = useState(0);
  const { content } = useContent();
  const core = content.brandCore;

  return (
    <section id="brand-core" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-display font-bold text-slate-900 mb-4">
            <EditableText path="brandCore.sectionTitle" value={core.sectionTitle} />
          </h2>
          <p className="text-slate-500 max-w-2xl mx-auto">
            <EditableText path="brandCore.sectionDesc" value={core.sectionDesc} />
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Interactive Circle Visualization */}
          <div className="relative aspect-square max-w-md mx-auto">
            {core.values.map((item, index) => {
              const isActive = activeTab === index;
              return (
                <div
                  key={index}
                  onClick={() => setActiveTab(index)}
                  className={`absolute inset-0 m-auto rounded-full border-2 transition-all duration-500 cursor-pointer flex items-center justify-center
                    ${isActive 
                      ? 'border-brand-500 bg-brand-50 shadow-[0_0_30px_rgba(14,165,233,0.2)] z-10 scale-100' 
                      : 'border-slate-200 bg-white hover:border-brand-200 z-0 scale-90 opacity-60'
                    }`}
                  style={{
                    width: `${100 - index * 25}%`,
                    height: `${100 - index * 25}%`,
                  }}
                >
                    {isActive && (
                        <span className="font-display font-bold text-2xl text-brand-600">
                             {index === 0 ? "WHY" : index === 1 ? "HOW" : "WHAT"}
                        </span>
                    )}
                </div>
              );
            })}
          </div>

          {/* Content Details */}
          <div className="space-y-6">
            {core.values.map((item, index) => (
              <div
                key={index}
                onClick={() => setActiveTab(index)}
                className={`p-6 rounded-2xl transition-all duration-300 cursor-pointer border ${
                  activeTab === index
                    ? 'bg-brand-50 border-brand-200 shadow-md translate-x-2'
                    : 'bg-white border-slate-100 hover:bg-slate-50 hover:border-slate-200'
                }`}
              >
                <div className="flex items-start gap-4">
                  <div className={`p-3 rounded-xl ${activeTab === index ? 'bg-brand-500 text-white' : 'bg-slate-100 text-slate-400'}`}>
                    {index === 0 && <Heart size={24} />}
                    {index === 1 && <Activity size={24} />}
                    {index === 2 && <CheckCircle2 size={24} />}
                  </div>
                  <div className="w-full">
                    <h3 className={`text-xl font-bold mb-1 ${activeTab === index ? 'text-brand-900' : 'text-slate-700'}`}>
                      <EditableText path={`brandCore.values[${index}].title`} value={item.title} />
                    </h3>
                    <p className={`text-sm font-semibold mb-2 ${activeTab === index ? 'text-brand-600' : 'text-slate-500'}`}>
                       <EditableText path={`brandCore.values[${index}].subtitle`} value={item.subtitle} />
                    </p>
                    <div className={`text-sm leading-relaxed ${activeTab === index ? 'text-slate-700' : 'text-slate-400'}`}>
                       <EditableText path={`brandCore.values[${index}].description`} value={item.description} multiline />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
