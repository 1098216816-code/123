import React, { useState, useEffect } from 'react';
import { Menu, X, PawPrint } from 'lucide-react';
import { NavItem } from '../types';

interface NavigationProps {
  activeSection: string;
  scrollToSection: (id: string) => void;
}

const navItems: NavItem[] = [
  { id: 'brand-core', label: '品牌认知' },
  { id: 'platforms', label: '平台策略' },
  { id: 'deep-dive', label: '深度策略' },
  { id: 'smile-box', label: '微笑盒子' },
  { id: 'guidelines', label: '品牌红线' },
];

export const Navigation: React.FC<NavigationProps> = ({ activeSection, scrollToSection }) => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'py-2' : 'py-4'
      }`}
    >
      <div className={`mx-auto max-w-6xl px-4 transition-all duration-300 ${
        scrolled ? 'bg-white/80 backdrop-blur-md shadow-lg rounded-full mx-4 mt-2' : 'bg-transparent'
      }`}>
        <div className="flex items-center justify-between h-14">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => scrollToSection('hero')}>
            <div className="bg-brand-600 p-2 rounded-xl text-white">
              <PawPrint size={20} />
            </div>
            <span className="font-display font-bold text-xl text-brand-900 tracking-tight">Aeicoi</span>
          </div>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-1">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => scrollToSection(item.id)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 ${
                  activeSection === item.id
                    ? 'bg-brand-100 text-brand-700 shadow-sm'
                    : 'text-slate-600 hover:text-brand-600 hover:bg-white/50'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

          {/* Mobile Toggle */}
          <button 
            className="md:hidden p-2 text-slate-600"
            onClick={() => setMobileOpen(!mobileOpen)}
          >
            {mobileOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div className="absolute top-full left-4 right-4 mt-2 p-4 bg-white/95 backdrop-blur-xl rounded-2xl shadow-xl border border-slate-100 md:hidden flex flex-col gap-2 animate-in slide-in-from-top-4 fade-in duration-200">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                scrollToSection(item.id);
                setMobileOpen(false);
              }}
              className={`w-full text-left px-4 py-3 rounded-xl text-sm font-medium transition-colors ${
                activeSection === item.id
                  ? 'bg-brand-50 text-brand-700'
                  : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
      )}
    </nav>
  );
};