import { AppContent } from '../types';

export const defaultContent: AppContent = {
  hero: {
    tagline: "第一阶段：品牌市场教育",
    titlePart1: "把",
    titleHighlight: "微笑",
    titlePart2: "装进盒子",
    subTitleEnglish: "Open the box, see the smile.",
    description: "Aeicoi（微笑盒子）不仅仅是鱼油，而是Claire Bennett为爱宠打造的“快乐承诺”。无腥味、纯净、每一次开启都是喜悦。",
    primaryBtnText: "探索品牌故事",
    primaryBtnLink: "brand-core",
    secondaryBtnText: "查看微笑盒子",
    secondaryBtnLink: "smile-box",
    productImage: "", // Empty string will use default CSS/Icon fallback
    floatingTag1Title: "RTG Extraction",
    floatingTag1Sub: "Technology",
    floatingTag2Title: "No Fishy Smell",
    floatingTag2Sub: "Promise",
  },
  brandCore: {
    sectionTitle: "核心理念：定义你的品牌",
    sectionDesc: "基于 Claire Bennett 的故事，我们建立品牌的 Golden Circle。",
    values: [
      {
        title: 'Why (价值观)',
        subtitle: '一切为了毛孩子健康与家庭快乐',
        description: 'Claire Bennett的故事：从担忧爱犬健康，到寻找完美解决方案。我们不只是卖鱼油，而是消除养宠生活中的隐形焦虑。',
      },
      {
        title: 'How (过程)',
        subtitle: 'RTG萃取技术',
        description: '采用高成本的RTG萃取技术，实现真正的高纯度与吸收率。每一个环节都追求极致，只为把最好的带给毛孩子。',
      },
      {
        title: 'What (结果)',
        subtitle: '解决痛点的健康问题',
        description: '一颗没有腥味、只有快乐的鱼油。解决了家长担心家里有异味的痛点，也解决了宠物挑食的问题。',
      },
    ]
  },
  platform: {
    sectionTitle: "分平台策略矩阵",
    sectionDesc: "针对不同平台的属性，定制化内容分发，建立全方位的品牌信任感。",
    strategies: [
      {
        platform: 'YouTube',
        role: '深度内容',
        slogan: 'The Documentary Channel',
        icon: 'youtube',
        color: 'hover:border-red-500 hover:shadow-red-100',
        tactics: [
          '第一集：宠物健康问题发现',
          '第二集：糟糕的误养与鱼油尝试',
          '第三集：深夜厨房与成分剖析',
          '第四集：真正的爱与解决方案 (RTG)',
          'Brand Documentary: 创始人的旅程',
          'SEO优化: 标题覆盖痛点关键词'
        ]
      },
      {
        platform: 'Instagram',
        role: '视觉美学',
        slogan: 'The Visual Channel',
        icon: 'instagram',
        color: 'hover:border-pink-500 hover:shadow-pink-100',
        tactics: [
          '视觉呈现：干净、高级的白蓝色调',
          'A/B测试：Before & After 对比图',
          'Reels: 使用流行音乐，快节奏展示',
          'Stories: "此路不通" vs "完美方案"',
          '口号：All the Omega-3s. None of the mess.'
        ]
      },
      {
        platform: 'TikTok',
        role: '真实原生',
        slogan: 'The Raw & Real Channel',
        icon: 'tiktok',
        color: 'hover:border-slate-800 hover:shadow-slate-200',
        tactics: [
          '达人投放 (Seeding): 100个轻量级KOC',
          '真实感 (Authenticity): 怼脸拍',
          'ASMR: 狗狗咀嚼声，开瓶的声音',
          'Hook: 前3秒展示"尴尬"或"惊喜"',
          '美好场景：Aeicoi让生活更精致'
        ]
      },
      {
        platform: 'Facebook',
        role: '社区连接',
        slogan: 'The Community Channel',
        icon: 'facebook',
        color: 'hover:border-blue-600 hover:shadow-blue-100',
        tactics: [
          '第一人称叙述的创始人故事',
          '长文 Storytelling + 情感图片',
          '社群运营: VIP用户群，分享故事',
          '直播 (Live): 新品发布，定期问答',
          '广告: 投放高互动率的品牌宣传片'
        ]
      }
    ]
  },
  deepDive: {
    sectionTitle: "深度策略与执行方案",
    sectionDesc: "点击下方主题按钮，查看详细的切入角度与落地执行计划。",
    items: [
      {
        title: "品牌故事切入点",
        summary: "无论是创始人故事还是“挑战者”叙事，我们有四个核心角度来打动用户。",
        fullContent: "1. 起源故事 (The Origin Story)\n内容: 为什么创办? 比如“因为找不到适合自家敏感肌狗狗的护肤品，所以我决定自己做”。\n运营: YouTube, Website, Instagram Highlights。\n\n2. 挑战与克服 (The Underdog Story)\n内容: 展示失败。比如“这个样品我们要测试了100次才成功”。人们喜欢看到努力的过程，而不是直接看到完美的结果。\n运营: TikTok, Reels。\n\n3. 用户英雄模式 (Customer as Hero)\n内容: 用户才是英雄，用户才是关键，品牌是帮助英雄成功的宝剑。分享UGC（用户生成内容），让用户代言。\n运营: 所有平台，特别是Ins和FB。\n\n4. 社会责任 (Values & Mission)\n内容: 环保、平权、慈善，比如“每卖出一件衣服，我们就种一棵树”。\n运营: 提升品牌格调，适合YouTube专题片和Ins图文。"
      },
      {
        title: "执行落地计划 (Action Plan)",
        summary: "从素材库建立到KOC投放的详细执行步骤，确保营销动作有条不紊。",
        fullContent: "1. 素材库建立 (Content Bank)\n一次拍摄，多次使用。\n- 拍一个长视频（发YouTube）。\n- 剪辑成3-5个短视频精华（发Shorts, Reels, TikTok）。\n- 截图高光时刻（发Ins）。\n- 提炼金句（发Twitter/Threads/FB）。\n\n2. KOL/KOC 投放\n让网红用他们的语言讲你的故事。不仅是带货，而是让他们解释“为什么喜欢这个品牌的理念”。\n\n3. 统一视觉识别 (Visual Identity)\n不管在TikTok还是Ins，Logo的露出方式、品牌的主色调、字体需要保持一致，加深记忆。\n\n4. 互动是故事的一部分\n回复评论！回复评论！回复评论！你的回复态度（幽默、专业、温暖）也是品牌人设的一部分。\n\n5. 30天全额退款 (Money Back Guarantee)\n降低用户尝试门槛，消除不信任感。"
      },
      {
        title: "总结与金句",
        summary: "所有的营销动作都为了那一个“微笑”。",
        fullContent: "一句话视觉符号：\n在所有平台的素材中，都要有意识地通过手指划过、光影照射等方式，强调那条金色的“微笑曲线”。\n\nHashtag 策略：\n创造品牌专属标签 #AeicoiSmileBox ，并混用大流量标签 #DogHealth #PetSupplements #GlowUp 。\n\nKOL/KOC 寄语：\n给宠物博主寄送产品时，附带一张卡片：“Open the box, see the smile.”（开启盒子，看见微笑），引导他们拍摄开箱时的惊喜感。"
      }
    ]
  },
  smileBox: {
    sectionTitle: "超级符号：",
    sectionHighlight: "微笑盒子",
    sectionSub: "(The Smile Box)",
    quote: "\"Open the box, see the smile.\"",
    designTitle: "设计解读",
    designDesc: "上半部分 (白): 代表纯净的美味。下半部分 (蓝): 代表深海的滋养。中间金色弧线: 连接科学与美味的“微笑”曲线。",
    visualTitle: "视觉呈现 (Unboxing)",
    visualDesc: "拍摄时强调手指沿着金色弧线打开包装的动作，配合音效 “叮” 的一声。包装盒如笑脸般展开。",
    audioTitle: "听觉符号 (Sonic Logo)",
    audioDesc: "清脆的 “Ding!” (清楚的声音) 或 “Pop!” (开瓶声) + 一段上扬的 “Bling” 魔法音效。",
    boxImageTextTop: "Aeicoi",
    boxImageTextBottom: "Pure Omega-3"
  },
  redLines: {
    sectionTitle: "品牌红线 (Red Lines)",
    sectionDesc: "保持一致性是建立信任的关键。以下规则在所有平台必须严格遵守。",
    visualTitle: "视觉规范 (Visual Look)",
    colorTitle: "锁定色板 (Color Grading)",
    colorDesc: "背景必须干净：环境光必须明亮，尽量使用白色、浅色沙发。统一滤镜 (LUT)：高光偏冷白，阴影偏蓝。",
    fontTitle: "字体与排版",
    fontDesc: "不要使用手写体或花哨的艺术字。英文标题统一使用 Sans Serif (Inter/Helvetica)。",
    audioTitle: "听觉与调性 (Tone & Audio)",
    personaTitle: "品牌人设 (Persona)",
    personaDesc: [
      "懂得科学喂养的专业朋友。",
      "既不是高高在上的白大褂医生。",
      "也不是只会卖萌的无脑主播。",
      "正向语气：温暖、自信、轻松、有条理。"
    ],
    dontsTitle: "绝对禁止 (Don'ts)",
    dontsList: [
      "杂乱背景",
      "疯狂鬼畜剪辑",
      "昏暗光线",
      "悲伤、惊悚音乐"
    ]
  }
};