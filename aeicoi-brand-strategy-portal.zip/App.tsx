import React, { useState } from 'react';
import { ContentProvider } from './context/ContentContext';
import { Navigation } from './components/Navigation';
import { Hero } from './components/Hero';
import { BrandCore } from './components/BrandCore';
import { PlatformStrategy } from './components/PlatformStrategy';
import { StrategyDeepDive } from './components/StrategyDeepDive';
import { SmileBox } from './components/SmileBox';
import { RedLines } from './components/RedLines';
import { Footer } from './components/Footer';
import { AdminToolbar } from './components/cms/AdminComponents';

const AppContent: React.FC = () => {
  const [activeSection, setActiveSection] = useState('hero');

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setActiveSection(id);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans selection:bg-brand-200 selection:text-brand-900">
      <Navigation activeSection={activeSection} scrollToSection={scrollToSection} />
      
      <main>
        <Hero scrollToSection={scrollToSection} />
        <BrandCore />
        <PlatformStrategy />
        <StrategyDeepDive />
        <SmileBox />
        <RedLines />
      </main>

      <Footer />
      <AdminToolbar />
    </div>
  );
};

const App: React.FC = () => {
  return (
    <ContentProvider>
      <AppContent />
    </ContentProvider>
  );
};

export default App;